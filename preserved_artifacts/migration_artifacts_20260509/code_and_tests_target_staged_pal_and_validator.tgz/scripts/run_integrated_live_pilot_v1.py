#!/usr/bin/env python3
"""Run capped live integrated pilot v1 (targeted retry + structural-only rows)."""

from __future__ import annotations

import argparse
import csv
import json
import os
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import sys

REPO = Path(__file__).resolve().parents[1]
if str(REPO) not in sys.path:
    sys.path.insert(0, str(REPO))

from experiments.data import extract_final_answer
from experiments.targeted_discovery_retry import validate_prompt_no_gold

METHOD_NAME = (
    "direct_reserve_diverse_root_frontier_v1_guarded_k1_frontier4_frontier_tiebreak_pal_"
    "structural_commit_v1_targeted_retry_v1"
)


def _read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8") as f:
        return list(csv.DictReader(f))


def _write_csv(path: Path, fieldnames: list[str], rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for r in rows:
            w.writerow(r)


def _norm_num(text: str) -> str:
    raw = str(text or "").strip()
    if not raw:
        return ""
    final = extract_final_answer(raw).strip().replace(",", "")
    if not final:
        return ""
    try:
        v = float(final)
    except ValueError:
        return ""
    return str(int(v)) if v.is_integer() else f"{v:.10g}"


def _cohere_chat(prompt: str, *, model: str, temperature: float, max_tokens: int) -> str:
    import cohere  # type: ignore

    api_key = os.getenv("COHERE_API_KEY", "")
    if not api_key:
        raise RuntimeError("COHERE_API_KEY is required")
    client = cohere.ClientV2(api_key=api_key)
    resp = client.chat(
        model=model,
        messages=[{"role": "user", "content": prompt}],
        temperature=temperature,
        max_tokens=max_tokens,
    )
    out = ""
    msg = getattr(resp, "message", None)
    if msg is not None and getattr(msg, "content", None):
        for part in getattr(msg, "content"):
            t = getattr(part, "text", "")
            if t:
                out += str(t)
    return out.strip()


def _load_prompt_maps(v21_dry: Path, v1_dry: Path) -> dict[tuple[str, str], dict[str, str]]:
    out: dict[tuple[str, str], dict[str, str]] = {}
    for r in _read_csv(v21_dry / "targeted_retry_v21_cases.csv"):
        cid = str(r.get("case_id") or "").strip()
        sc = str(r.get("scaffold") or "").strip()
        if cid and sc:
            rp = str(r.get("prompt_path") or "").strip()
            abs_path = (v21_dry / rp).resolve()
            rel_path = str(abs_path.relative_to(REPO)).replace("\\", "/") if str(abs_path).startswith(str(REPO)) else str(abs_path)
            row = dict(r)
            row["prompt_path"] = rel_path
            row["prompt_abspath"] = str(abs_path)
            out[(cid, sc)] = row
    for r in _read_csv(v1_dry / "targeted_retry_cases.csv"):
        cid = str(r.get("case_id") or "").strip()
        sc = str(r.get("selected_scaffold") or "").strip()
        if cid and sc and (cid, sc) not in out:
            rp = str(r.get("prompt_path") or "").strip()
            abs_path = (v1_dry / rp).resolve()
            rel_path = str(abs_path.relative_to(REPO)).replace("\\", "/") if str(abs_path).startswith(str(REPO)) else str(abs_path)
            out[(cid, sc)] = {
                "case_id": cid,
                "scaffold": sc,
                "prompt_version": "v1",
                "prompt_path": rel_path,
                "prompt_abspath": str(abs_path),
                "gold_answer": str(r.get("gold_answer") or "").strip(),
                "current_pal_prediction": str(r.get("current_pal_prediction") or "").strip(),
                "source_artifacts": str(r.get("source_artifacts") or "").strip(),
            }
    return out


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument(
        "--integrated-replay-dir",
        type=Path,
        default=REPO / "outputs/integrated_structural_commit_targeted_retry_v1_replay_20260508T020401Z",
    )
    ap.add_argument(
        "--targeted-consolidation-dir",
        type=Path,
        default=REPO / "outputs/targeted_discovery_retry_consolidated_20260508T015847Z",
    )
    ap.add_argument(
        "--v21-dry-run-dir",
        type=Path,
        default=REPO / "outputs/targeted_discovery_retry_v21_dry_run_20260508T014403Z",
    )
    ap.add_argument(
        "--v1-dry-run-dir",
        type=Path,
        default=REPO / "outputs/targeted_discovery_retry_v1_dry_run_20260508T010738Z",
    )
    ap.add_argument("--model", default="command-a-03-2025")
    ap.add_argument("--temperature", type=float, default=0.0)
    ap.add_argument("--max-tokens", type=int, default=700)
    args = ap.parse_args()

    integrated_rows = _read_csv(args.integrated_replay_dir / "integrated_replay_cases.csv")
    consolidated_rows = _read_csv(args.targeted_consolidation_dir / "consolidated_by_case.csv")
    consolidated_by_case = {str(r.get("case_id") or ""): r for r in consolidated_rows if r.get("case_id")}
    prompt_map = _load_prompt_maps(args.v21_dry_run_dir, args.v1_dry_run_dir)

    targeted_candidates: list[dict[str, str]] = []
    structural_candidates: list[dict[str, str]] = []
    for r in integrated_rows:
        cid = str(r.get("case_id") or "").strip()
        if not cid:
            continue
        if r.get("pilot_track"):
            continue
        mech = str(r.get("original_mechanism") or "").strip()
        ires = str(r.get("integrated_result") or "").strip()
        if mech == "gold_absent_discovery" and ires == "fixed_estimated":
            cres = consolidated_by_case.get(cid, {})
            sc = str(cres.get("scaffold") or "").strip()
            pv = str(cres.get("recommended_prompt_version") or "").strip()
            if sc in {"quantity_ledger", "rate_table", "before_after_state", "target_difference"} and pv:
                rr = dict(r)
                rr["scaffold"] = sc
                rr["prompt_version"] = pv
                targeted_candidates.append(rr)
        if mech == "present_not_selected" and ires == "fixed_estimated":
            structural_candidates.append(r)

    # Select targeted cases with scaffold minimums if available.
    by_scaffold: dict[str, list[dict[str, str]]] = {"quantity_ledger": [], "rate_table": [], "before_after_state": [], "target_difference": []}
    for r in targeted_candidates:
        by_scaffold[r["scaffold"]].append(r)
    for k in by_scaffold:
        by_scaffold[k] = sorted(by_scaffold[k], key=lambda x: str(x.get("case_id") or ""))

    selected_targeted: list[dict[str, str]] = []
    mins = {"quantity_ledger": 3, "rate_table": 3, "before_after_state": 2, "target_difference": 2}
    used: set[str] = set()
    for sc, m in mins.items():
        for r in by_scaffold[sc][:m]:
            cid = str(r["case_id"])
            if cid not in used:
                selected_targeted.append(r)
                used.add(cid)
    # fill up to 12 targeted max
    for sc in ["quantity_ledger", "rate_table", "before_after_state", "target_difference"]:
        for r in by_scaffold[sc]:
            cid = str(r["case_id"])
            if cid in used:
                continue
            if len(selected_targeted) >= 12:
                break
            selected_targeted.append(r)
            used.add(cid)

    selected_targeted = selected_targeted[:12]
    selected_structural = sorted(structural_candidates, key=lambda x: str(x.get("case_id") or ""))[:3]

    selected_rows: list[dict[str, Any]] = []
    prompt_versions_by_scaffold: dict[str, str] = {}
    for r in selected_targeted:
        cid = str(r["case_id"])
        sc = str(r["scaffold"])
        pm = prompt_map.get((cid, sc))
        if not pm:
            continue
        pv = str(pm.get("prompt_version") or "")
        prompt_versions_by_scaffold[sc] = pv
        selected_rows.append(
            {
                "case_id": cid,
                "mechanism": "gold_absent_discovery",
                "pilot_track": "targeted_retry",
                "scaffold": sc,
                "prompt_version": pv,
                "prompt_path": str(pm.get("prompt_path") or ""),
                "gold_answer": str(pm.get("gold_answer") or ""),
                "current_pal_prediction": str(pm.get("current_pal_prediction") or r.get("notes") or ""),
                "source_artifacts": str(pm.get("source_artifacts") or r.get("source_artifacts") or ""),
                "selection_reason": "allowlisted_integrated_fixed_estimate",
            }
        )
    for r in selected_structural:
        selected_rows.append(
            {
                "case_id": str(r.get("case_id") or ""),
                "mechanism": "present_not_selected",
                "pilot_track": "structural_commit_only",
                "scaffold": "",
                "prompt_version": "",
                "prompt_path": "",
                "gold_answer": "",
                "current_pal_prediction": "",
                "source_artifacts": str(r.get("source_artifacts") or ""),
                "selection_reason": "structural_fixed_from_replay_evidence",
            }
        )

    # final cap and dedup
    dedup: dict[str, dict[str, Any]] = {}
    for r in selected_rows:
        cid = str(r["case_id"])
        if cid and cid not in dedup:
            dedup[cid] = r
    selected_rows = list(dedup.values())[:15]

    targeted_rows = [r for r in selected_rows if r["pilot_track"] == "targeted_retry"]
    structural_rows = [r for r in selected_rows if r["pilot_track"] == "structural_commit_only"]
    planned_calls = len(targeted_rows)

    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    out = REPO / "outputs" / f"integrated_live_pilot_v1_{ts}"
    out.mkdir(parents=True, exist_ok=True)
    responses_dir = out / "responses"
    responses_dir.mkdir(parents=True, exist_ok=True)

    # preflight
    preflight: dict[str, Any] = {
        "cohere_api_key_set": bool(os.getenv("COHERE_API_KEY")),
        "planned_calls_ok": planned_calls <= 15,
        "all_prompt_files_exist": True,
        "no_ascii_gold_in_prompts": True,
        "no_unsupported_cases_selected": True,
        "no_duplicate_case_ids": len({r["case_id"] for r in selected_rows}) == len(selected_rows),
        "missing_prompt_paths": [],
        "gold_leak_case_ids": [],
    }
    for r in targeted_rows:
        pp = Path(str(prompt_map[(str(r["case_id"]), str(r["scaffold"]))].get("prompt_abspath", "")))
        if not pp.is_file():
            preflight["all_prompt_files_exist"] = False
            preflight["missing_prompt_paths"].append(str(pp))
            continue
        body = pp.read_text(encoding="utf-8")
        gold = str(r.get("gold_answer") or "").strip()
        if gold and not validate_prompt_no_gold(body, gold):
            preflight["no_ascii_gold_in_prompts"] = False
            preflight["gold_leak_case_ids"].append(r["case_id"])
        if str(r.get("scaffold") or "") not in {"quantity_ledger", "rate_table", "before_after_state", "target_difference"}:
            preflight["no_unsupported_cases_selected"] = False

    preflight_ok = all(
        bool(preflight[k])
        for k in [
            "cohere_api_key_set",
            "planned_calls_ok",
            "all_prompt_files_exist",
            "no_ascii_gold_in_prompts",
            "no_unsupported_cases_selected",
            "no_duplicate_case_ids",
        ]
    )

    manifest = {
        "method_name": METHOD_NAME,
        "source_integrated_replay_dir": str(args.integrated_replay_dir),
        "selected_case_count": len(selected_rows),
        "selected_targeted_retry_case_count": len(targeted_rows),
        "selected_structural_only_case_count": len(structural_rows),
        "max_cohere_calls": 15,
        "planned_cohere_calls": planned_calls,
        "model": args.model,
        "temperature": float(args.temperature),
        "max_tokens": int(args.max_tokens),
        "prompt_versions_by_scaffold": prompt_versions_by_scaffold,
        "no_gold_in_prompts_verified": bool(preflight["no_ascii_gold_in_prompts"]),
        "scoring_is_offline": True,
        "abort_conditions": [
            "COHERE_API_KEY missing",
            "planned calls exceeds 15",
            "missing prompt file",
            "gold leak in prompt",
            "unsupported case selected",
            "duplicate case id",
        ],
    }
    (out / "integrated_live_pilot_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    _write_csv(
        out / "selected_integrated_live_pilot_cases.csv",
        [
            "case_id",
            "mechanism",
            "pilot_track",
            "scaffold",
            "prompt_version",
            "prompt_path",
            "gold_answer",
            "current_pal_prediction",
            "source_artifacts",
            "selection_reason",
        ],
        selected_rows,
    )
    (out / "preflight_status.json").write_text(json.dumps(preflight, indent=2), encoding="utf-8")

    results: list[dict[str, Any]] = []
    api_errors: list[str] = []
    parsing_ambiguities = 0
    calls_made = 0

    if preflight_ok:
        for r in targeted_rows:
            cid = str(r["case_id"])
            prompt = (REPO / str(r["prompt_path"])).read_text(encoding="utf-8")
            resp_path = responses_dir / f"{cid}.txt"
            parsed = ""
            notes = ""
            try:
                txt = _cohere_chat(prompt, model=args.model, temperature=float(args.temperature), max_tokens=int(args.max_tokens))
                calls_made += 1
                resp_path.write_text(txt, encoding="utf-8")
                parsed = _norm_num(txt)
            except Exception as exc:  # noqa: BLE001
                api_errors.append(f"{cid}: {type(exc).__name__}: {exc}")
                notes = f"api_error:{type(exc).__name__}"
                resp_path.write_text("", encoding="utf-8")
            gold = str(r.get("gold_answer") or "").strip()
            goldn = _norm_num(gold)
            exact = bool(parsed and goldn and parsed == goldn)
            pal = str(r.get("current_pal_prediction") or "").strip()
            paln = _norm_num(pal)
            improved = "unknown"
            if parsed and goldn and paln:
                improved = "yes" if (parsed == goldn and paln != goldn) else ("no" if parsed == goldn else "unknown")
            if not parsed and not notes:
                parsing_ambiguities += 1
                notes = "parse_ambiguous_or_empty"
            results.append(
                {
                    "case_id": cid,
                    "pilot_track": "targeted_retry",
                    "scaffold": r["scaffold"],
                    "prompt_version": r["prompt_version"],
                    "cohere_call_made": "yes",
                    "parsed_final_answer": parsed,
                    "gold_answer": gold,
                    "exact_match": str(exact).lower(),
                    "improved_over_current_pal": improved,
                    "structural_commit_result_if_applicable": "",
                    "response_text_path": str(resp_path.relative_to(out)).replace("\\", "/"),
                    "notes": notes,
                }
            )
    else:
        for r in targeted_rows:
            results.append(
                {
                    "case_id": r["case_id"],
                    "pilot_track": "targeted_retry",
                    "scaffold": r["scaffold"],
                    "prompt_version": r["prompt_version"],
                    "cohere_call_made": "no",
                    "parsed_final_answer": "",
                    "gold_answer": str(r.get("gold_answer") or ""),
                    "exact_match": "",
                    "improved_over_current_pal": "",
                    "structural_commit_result_if_applicable": "",
                    "response_text_path": "",
                    "notes": "preflight_failed_no_api_call",
                }
            )

    # structural rows: no cohere call, score from replay estimate only
    for r in structural_rows:
        results.append(
            {
                "case_id": r["case_id"],
                "pilot_track": "structural_commit_only",
                "scaffold": "",
                "prompt_version": "",
                "cohere_call_made": "no",
                "parsed_final_answer": "",
                "gold_answer": "",
                "exact_match": "",
                "improved_over_current_pal": "",
                "structural_commit_result_if_applicable": "fixed_estimated_from_replay",
                "response_text_path": "",
                "notes": "scored_from_structural_replay_evidence",
            }
        )

    _write_csv(
        out / "integrated_live_pilot_results.csv",
        [
            "case_id",
            "pilot_track",
            "scaffold",
            "prompt_version",
            "cohere_call_made",
            "parsed_final_answer",
            "gold_answer",
            "exact_match",
            "improved_over_current_pal",
            "structural_commit_result_if_applicable",
            "response_text_path",
            "notes",
        ],
        results,
    )

    targeted_exact = sum(1 for r in results if r["pilot_track"] == "targeted_retry" and r["exact_match"] == "true")
    targeted_total = sum(1 for r in results if r["pilot_track"] == "targeted_retry")
    structural_fixed = sum(
        1 for r in results if r["pilot_track"] == "structural_commit_only" and "fixed" in str(r["structural_commit_result_if_applicable"])
    )
    structural_total = sum(1 for r in results if r["pilot_track"] == "structural_commit_only")
    combined_fixed = targeted_exact + structural_fixed
    combined_total = len(results)

    summary = {
        "total_selected_cases": len(selected_rows),
        "actual_cohere_calls": calls_made,
        "targeted_retry_exact": targeted_exact,
        "targeted_retry_total": targeted_total,
        "structural_commit_fixed": structural_fixed,
        "structural_commit_total": structural_total,
        "combined_exact_or_fixed": combined_fixed,
        "combined_total": combined_total,
        "api_errors": api_errors,
        "parsing_ambiguities": parsing_ambiguities,
        "no_gold_leakage": bool(preflight["no_ascii_gold_in_prompts"]),
    }
    (out / "integrated_live_pilot_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    by_track_scaffold = Counter((r["pilot_track"], r["scaffold"] or "none") for r in results)
    report = "\n".join(
        [
            "# Integrated live pilot v1",
            "",
            f"- Selected cases: {len(selected_rows)}",
            f"- Targeted retry cases: {len(targeted_rows)}",
            f"- Structural-only cases: {len(structural_rows)}",
            f"- Cohere calls used: {calls_made}",
            "",
            "## Results",
            f"- targeted_retry_exact: {targeted_exact}/{targeted_total}",
            f"- structural_commit_fixed: {structural_fixed}/{structural_total}",
            f"- combined_exact_or_fixed: {combined_fixed}/{combined_total}",
            "",
            "## By track/scaffold",
            "```json",
            json.dumps({f"{k[0]}::{k[1]}": v for k, v in by_track_scaffold.items()}, indent=2),
            "```",
            "",
            "## Failures / errors",
            "```json",
            json.dumps({"api_errors": api_errors, "parsing_ambiguities": parsing_ambiguities}, indent=2),
            "```",
            "",
            "Not yet sufficient for a broad external_l1_max checkpoint; use as end-to-end smoke evidence only.",
        ]
    )
    (out / "integrated_live_pilot_report.md").write_text(report, encoding="utf-8")
    print(out)


if __name__ == "__main__":
    main()

