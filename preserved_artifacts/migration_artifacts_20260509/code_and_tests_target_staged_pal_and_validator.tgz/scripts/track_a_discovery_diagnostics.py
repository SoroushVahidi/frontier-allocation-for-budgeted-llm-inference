#!/usr/bin/env python3
"""Track A discovery diagnostics — offline PAL telemetry only (no API, no controllers)."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Any, Callable

REPO_ROOT = Path(__file__).resolve().parents[1]

from experiments.gsm8k_structural_validate import validate_gsm8k_candidate

from scripts.evaluate_gsm8k_structural_validator import (
    assign_cohort,
    build_candidate_specs,
    guardrail_case_ids,
    load_csv_rows,
    load_failure_cluster_map,
    load_pal_all_results,
    load_selected_failures,
)

DEFAULT_BUNDLE = (
    REPO_ROOT / "outputs/cohere_collect_pal_failure_cases_vs_3_external_20260507T161935Z"
)
DEFAULT_OUT = REPO_ROOT / "outputs/gsm8k_structural_validator_eval_20260507"

TRACK_ROLES = ("current_final", "pal_stdout")


def _spec_by_role(specs: list[dict[str, Any]], role: str) -> dict[str, Any] | None:
    priority = (
        "replay_pal_final",
        "pal_execution_stdout",
        "selected_failure_pal",
        "all_results_pal",
    )

    def rank(sf: str) -> int:
        try:
            return priority.index(sf)
        except ValueError:
            return len(priority)

    cands = [s for s in specs if s.get("candidate_role") == role]
    if not cands:
        return None
    return min(cands, key=lambda s: rank(str(s.get("source_family") or "")))


def _full_validate(spec: dict[str, Any]) -> dict[str, Any]:
    return validate_gsm8k_candidate(
        problem_text=spec["problem_text"],
        candidate_answer=spec["candidate_answer"],
        candidate_trace=spec.get("trace") or None,
        candidate_code=spec.get("code") or None,
        source_family=spec.get("source_family"),
        execution_metadata=spec.get("execution_metadata"),
    )


# --- Trigger families (offline candidates for future retry policy) -----------------

TriggerFn = Callable[[dict[str, Any]], bool]


def _warnset(v: dict[str, Any]) -> set[str]:
    return {str(w) for w in (v.get("warnings") or [])}


def trig_low_cov_and_missing_cue(v: dict[str, Any]) -> bool:
    cov = v.get("quantity_coverage")
    low = cov is not None and float(cov) < 0.34
    ws = _warnset(v)
    miss = any(w.startswith("missing_operation_cue_in_trace_or_code:") for w in ws)
    return low and miss


def trig_temporal_gap(v: dict[str, Any]) -> bool:
    req = list(v.get("operation_cues_required") or [])
    if "temporal" not in req:
        return False
    ws = _warnset(v)
    return bool(
        ws
        & {
            "missing_operation_cue_in_trace_or_code:temporal",
            "temporal_story_weak_follow_through_in_trace",
        }
    )


def trig_rate_gap(v: dict[str, Any]) -> bool:
    req = list(v.get("operation_cues_required") or [])
    if "rate" not in req:
        return False
    ws = _warnset(v)
    return bool(
        ws
        & {
            "missing_operation_cue_in_trace_or_code:rate",
            "rate_question_weak_operator_evidence_in_trace",
        }
    )


def trig_total_agg_gap(v: dict[str, Any]) -> bool:
    req = list(v.get("operation_cues_required") or [])
    if "total" not in req:
        return False
    ws = _warnset(v)
    return bool(
        ws
        & {
            "missing_operation_cue_in_trace_or_code:total",
            "aggregation_question_weak_total_evidence_in_trace",
        }
    )


def trig_difference_gap(v: dict[str, Any]) -> bool:
    req = list(v.get("operation_cues_required") or [])
    if "difference" not in req:
        return False
    ws = _warnset(v)
    return bool(
        ws
        & {
            "missing_operation_cue_in_trace_or_code:difference",
            "comparison_question_weak_contrast_evidence_in_trace",
        }
    )


def trig_target_type_mismatch(v: dict[str, Any]) -> bool:
    return v.get("target_type_match") is False


def trig_exec_or_syntax_bad_and_low_cov(v: dict[str, Any]) -> bool:
    cov = v.get("quantity_coverage")
    low = cov is None or float(cov) < 0.34
    syn = v.get("code_syntax_ok")
    ex = v.get("exec_ok")
    bad = syn is False or ex is False
    return bool(bad and low)


TRIGGER_REGISTRY: dict[str, TriggerFn] = {
    "low_cov_and_missing_operation_cue": trig_low_cov_and_missing_cue,
    "temporal_cue_gap": trig_temporal_gap,
    "rate_ratio_cue_gap": trig_rate_gap,
    "total_aggregation_cue_gap": trig_total_agg_gap,
    "difference_contrast_cue_gap": trig_difference_gap,
    "target_type_mismatch": trig_target_type_mismatch,
    "exec_or_syntax_bad_plus_low_cov": trig_exec_or_syntax_bad_and_low_cov,
}


def discovery_cohort_label(ft_map: dict[str, str], tier_map: dict[str, str], cid: str) -> str:
    ft = ft_map.get(cid, "")
    if ft != "gold_absent_discovery":
        return ""
    tier = tier_map.get(cid, "")
    if tier == "preferred":
        return "gold_absent_discovery_preferred"
    if tier == "secondary":
        return "gold_absent_discovery_secondary"
    return "gold_absent_discovery_unknown_tier"


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--bundle-dir", type=Path, default=DEFAULT_BUNDLE)
    ap.add_argument("--out-dir", type=Path, default=DEFAULT_OUT)
    args = ap.parse_args()
    bundle = args.bundle_dir.resolve()
    out_dir = args.out_dir.resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    paths = {
        "replay_csv": bundle / "present_not_selected_replay_table.csv",
        "failure_cluster": bundle / "failure_cluster_summary.csv",
        "all_results": bundle / "all_results.jsonl",
        "casebook": bundle / "all_casebook.csv",
        "selected_failures": bundle / "selected_failure_cases.jsonl",
    }

    pal_by_case = load_pal_all_results(paths["all_results"])
    ft_map = load_failure_cluster_map(paths["failure_cluster"])
    tier_map: dict[str, str] = {}
    with paths["failure_cluster"].open(encoding="utf-8", newline="") as f:
        r = csv.DictReader(f)
        for row in r:
            cid = str(row.get("case_id") or "").strip()
            if cid:
                tier_map[cid] = str(row.get("tier") or "").strip()

    replay_rows = load_csv_rows(paths["replay_csv"])
    replay_by_id = {r["case_id"]: r for r in replay_rows if r.get("case_id")}
    replay_ids = set(replay_by_id.keys())

    casebook_rows = load_csv_rows(paths["casebook"])
    casebook_by_id = {r["case_id"]: r for r in casebook_rows if r.get("case_id")}
    guard_ids = guardrail_case_ids(casebook_rows)
    selected_by_case = load_selected_failures(paths["selected_failures"])

    # Case universe for Track A tables
    gold_absent_ids = {cid for cid, ft in ft_map.items() if ft == "gold_absent_discovery"}
    pn_ids = replay_ids  # present-not-selected replay bundle
    guard_ids_set = set(guard_ids)

    analysis_ids: list[str] = []
    seen: set[str] = set()

    def add(cid: str) -> None:
        if cid and cid not in seen:
            seen.add(cid)
            analysis_ids.append(cid)

    for cid in sorted(gold_absent_ids | pn_ids | guard_ids_set):
        add(cid)

    diag_rows: list[dict[str, Any]] = []
    # Primary row per case for triggers: current_final only
    primary_rows: list[tuple[str, str, dict[str, Any]]] = []

    for cid in analysis_ids:
        cohort = assign_cohort(cid, replay_ids=replay_ids, ft_map=ft_map, guardrail_ids=guard_ids_set)
        replay_row = replay_by_id.get(cid)
        pal_row = pal_by_case.get(cid)
        cb_row = casebook_by_id.get(cid)
        sf_row = selected_by_case.get(cid)

        if replay_row:
            gold = replay_row.get("gold_answer_raw") or ""
            question = replay_row.get("question") or ""
        elif cb_row:
            gold = cb_row.get("gold_answer") or ""
            question = cb_row.get("question") or ""
        elif sf_row:
            gold = str(sf_row.get("gold_answer") or "")
            question = str(sf_row.get("question") or "")
        elif pal_row:
            gold = str(pal_row.get("gold_answer") or "")
            question = str(pal_row.get("question") or "")
        else:
            continue

        disc_lab = discovery_cohort_label(ft_map, tier_map, cid)

        specs, miss = build_candidate_specs(
            cohort=cohort,
            case_id=cid,
            question=question,
            gold=gold,
            replay_row=replay_row,
            pal_row=pal_row,
            casebook_row=cb_row,
            selected_failure=sf_row,
        )

        for role in TRACK_ROLES:
            sp = _spec_by_role(specs, role)
            if sp is None:
                continue
            v = _full_validate(sp)
            tr = str(sp.get("trace") or "")
            cd = str(sp.get("code") or "")
            row_out = {
                "case_id": cid,
                "track_a_cohort": cohort,
                "discovery_tier": disc_lab or "",
                "candidate_role": role,
                "source_family": sp.get("source_family"),
                "trace_len": len(tr),
                "code_len": len(cd),
                "missing_metadata_flags": json.dumps(miss),
                "warnings_json": json.dumps(v.get("warnings") or []),
                "warnings_count": len(v.get("warnings") or []),
                "unused_salient_quantities_json": json.dumps(v.get("unused_salient_quantities") or []),
                "quantity_coverage": v.get("quantity_coverage"),
                "operation_cues_required_json": json.dumps(v.get("operation_cues_required") or []),
                "operation_cues_found_json": json.dumps(v.get("operation_cues_found") or []),
                "target_question_type": v.get("target_question_type"),
                "target_type_match": v.get("target_type_match"),
                "code_syntax_ok": v.get("code_syntax_ok"),
                "exec_ok": v.get("exec_ok"),
                "structural_score": v.get("structural_score"),
                "abstain_reasons_json": json.dumps(v.get("abstain_reasons") or []),
            }
            diag_rows.append(row_out)
            if role == "current_final":
                primary_rows.append((cid, cohort, v))

    # --- Trigger statistics (primary: current_final only) ---
    bucket_for_case: dict[str, str] = {}
    for cid in analysis_ids:
        if cid in gold_absent_ids:
            bucket_for_case[cid] = discovery_cohort_label(ft_map, tier_map, cid) or "gold_absent_discovery"
        elif cid in pn_ids:
            bucket_for_case[cid] = "present_not_selected"
        elif cid in guard_ids_set:
            bucket_for_case[cid] = "guardrail_correct"
        else:
            bucket_for_case[cid] = "other"

    cf_by_case: dict[str, dict[str, Any]] = {}
    for cid, _cohort, v in primary_rows:
        cf_by_case[cid] = v

    trigger_stats: dict[str, dict[str, Any]] = {}
    for tname, fn in TRIGGER_REGISTRY.items():
        fired_ga_pref = 0
        fired_ga_sec = 0
        fired_pn = 0
        fired_gr = 0
        fired_total = 0
        examples_ga: list[str] = []
        examples_pn: list[str] = []
        examples_gr: list[str] = []

        for cid, v in cf_by_case.items():
            if not fn(v):
                continue
            fired_total += 1
            b = bucket_for_case.get(cid, "")
            if b == "gold_absent_discovery_preferred":
                fired_ga_pref += 1
                if len(examples_ga) < 5:
                    examples_ga.append(cid)
            elif b == "gold_absent_discovery_secondary":
                fired_ga_sec += 1
                if len(examples_ga) < 8:
                    examples_ga.append(cid)
            elif b == "present_not_selected":
                fired_pn += 1
                if len(examples_pn) < 5:
                    examples_pn.append(cid)
            elif b == "guardrail_correct":
                fired_gr += 1
                if len(examples_gr) < 5:
                    examples_gr.append(cid)

        ga_total = len([c for c in bucket_for_case if bucket_for_case[c].startswith("gold_absent")])
        pn_total = len([c for c in bucket_for_case if bucket_for_case[c] == "present_not_selected"])
        gr_total = len([c for c in bucket_for_case if bucket_for_case[c] == "guardrail_correct"])

        fired_ga_all = fired_ga_pref + fired_ga_sec
        precision_like = fired_ga_all / fired_total if fired_total else 0.0
        recall_like_ga = fired_ga_all / ga_total if ga_total else 0.0
        fp_rate_guardrail = fired_gr / gr_total if gr_total else 0.0

        trigger_stats[tname] = {
            "fired_gold_absent_preferred": fired_ga_pref,
            "fired_gold_absent_secondary": fired_ga_sec,
            "fired_gold_absent_all": fired_ga_all,
            "fired_present_not_selected": fired_pn,
            "fired_guardrail_correct": fired_gr,
            "fired_total_across_buckets": fired_total,
            "bucket_totals": {
                "gold_absent_cases": ga_total,
                "present_not_selected_cases": pn_total,
                "guardrail_correct_cases": gr_total,
            },
            "approx_precision_gold_absent_given_fired": precision_like,
            "fraction_gold_absent_cases_firing": recall_like_ga,
            "false_positive_rate_guardrail_current_final": fp_rate_guardrail,
            "example_case_ids_gold_absent": examples_ga,
            "example_case_ids_present_not_selected": examples_pn,
            "example_case_ids_guardrail": examples_gr,
        }

    summary_out = {
        "documentation": {
            "primary_signal_row": "current_final per case for trigger tallies",
            "csv_includes_roles": list(TRACK_ROLES),
            "gold_used_only_offline": True,
        },
        "triggers": trigger_stats,
    }
    (out_dir / "track_a_warning_precision_summary.json").write_text(
        json.dumps(summary_out, indent=2), encoding="utf-8"
    )

    if diag_rows:
        fieldnames = list(diag_rows[0].keys())
        with (out_dir / "track_a_discovery_diagnostics.csv").open("w", encoding="utf-8", newline="") as f:
            w = csv.DictWriter(f, fieldnames=fieldnames)
            w.writeheader()
            for row in sorted(diag_rows, key=lambda x: (x["case_id"], x["candidate_role"])):
                w.writerow(row)

    # --- Markdown report ---
    md = _build_markdown_report(
        bundle=bundle,
        summary_json=summary_out,
        ga_pref_count=len([c for c in bucket_for_case if bucket_for_case[c] == "gold_absent_discovery_preferred"]),
        ga_sec_count=len([c for c in bucket_for_case if bucket_for_case[c] == "gold_absent_discovery_secondary"]),
    )
    (out_dir / "track_a_discovery_diagnostics.md").write_text(md, encoding="utf-8")

    print(f"Wrote Track A diagnostics to {out_dir}")


def _build_markdown_report(
    *,
    bundle: Path,
    summary_json: dict[str, Any],
    ga_pref_count: int,
    ga_sec_count: int,
) -> str:
    trig = summary_json["triggers"]
    lines = [
        "# Track A discovery diagnostics (GSM8K structural validator)",
        "",
        "Offline telemetry only — **no** API, **no** controllers, **no** selection wiring.",
        "",
        f"**Bundle:** `{bundle}`",
        "",
        "## A. Why Track B ranking is paused",
        "",
        "Mixed-evidence scoring and weak PAL-internal separation showed `structural_score` is **not** a reliable commitment ranker. "
        "See `stratified_report.md`. Track B scalar comparison is **paused** until evidence-normalized or pairwise designs exist.",
        "",
        "## B. Track A diagnostic objective",
        "",
        "Treat validator output as **Combinatorial-Opt-Agent-style tags**: detect missing quantity coverage, "
        "missing operation cues (rate/temporal/total/difference), target-type mismatches, and exec/syntax failures "
        "that might justify **targeted retry / richer trace** policies on **gold-absent discovery** failures.",
        "",
        "## C. Gold-absent warning patterns",
        "",
        f"- **Preferred** gold-absent cases in this bundle: **{ga_pref_count}**",
        f"- **Secondary** (both-wrong style) gold-absent cases: **{ga_sec_count}**",
        "",
        "Inspect per-case PAL `current_final` and `pal_stdout` rows in `track_a_discovery_diagnostics.csv` "
        "(warnings JSON, unused salient quantities, cues, coverage).",
        "",
        "## D. Guardrail false positives",
        "",
        "Guardrail cohort = PAL + best external **correct** (`all_casebook.csv`). "
        "Triggers are evaluated on **`current_final` only** for FP rates — correct answers should ideally **not** fire discovery retries.",
        "",
        "## E. Candidate trigger-family table",
        "",
        "| Trigger | Fire rate gold-absent | FP guardrail | Precision-like |",
        "|---------|----------------------|--------------|----------------|",
    ]
    for name, st in sorted(trig.items()):
        recall_ga = st["fraction_gold_absent_cases_firing"]
        fp_gr = st["false_positive_rate_guardrail_current_final"]
        prec = st["approx_precision_gold_absent_given_fired"]
        lines.append(
            f"| `{name}` | **{recall_ga:.3f}** ({st['fired_gold_absent_all']}/{st['bucket_totals']['gold_absent_cases']}) "
            f"| **{fp_gr:.3f}** ({st['fired_guardrail_correct']}/{st['bucket_totals']['guardrail_correct_cases']}) "
            f"| **{prec:.3f}** |"
        )

    lines.extend(
        [
            "",
            "## F. Promising triggers, if any",
            "",
            _promising_section(trig),
            "",
            "## G. Triggers to reject",
            "",
            _reject_section(trig),
            "",
            "## H. Relationship to Combinatorial Opt Agent",
            "",
            "Same principle: **cheap offline structural checks** as telemetry; triggers are **hypotheses** for policy, "
            "not proof of missing reasoning. Precision/recall here are **approximate** on a small GSM8K bundle.",
            "",
            "## I. Exact next implementation query",
            "",
            "> Implement optional **retry/TRCE hooks** gated behind env flags: when trigger X fires on PAL `current_final` "
            "and cohort is gold-absent discovery, allocate budget to structured scratchpad (state table / rate equation / "
            "aggregation template). **Do not** change default selection. Add regression harness on this CSV archive.",
            "",
            "**API:** not required for trigger evaluation.",
        ]
    )
    return "\n".join(lines)


def _promising_section(trig: dict[str, dict[str, Any]]) -> str:
    ranked = sorted(
        trig.items(),
        key=lambda kv: (
            -kv[1]["fraction_gold_absent_cases_firing"],
            kv[1]["false_positive_rate_guardrail_current_final"],
        ),
    )
    lines_out: list[str] = []
    for name, st in ranked[:4]:
        recall = st["fraction_gold_absent_cases_firing"]
        fp = st["false_positive_rate_guardrail_current_final"]
        lines_out.append(
            f"- **`{name}`:** fires on **{st['fired_gold_absent_all']}/{st['bucket_totals']['gold_absent_cases']}** "
            f"gold-absent cases (**{recall:.1%}** recall-like); guardrail FP **{fp:.1%}** "
            f"(`{st['fired_guardrail_correct']}/{st['bucket_totals']['guardrail_correct_cases']}`)."
        )
    lines_out.append(
        "**Interpretation:** No coarse trigger meets a strict **≥25% gold-absent recall & ≤25% guardrail FP** bar here. "
        "`temporal_cue_gap` shows the **strongest recall-like signal** among cue-gap families; treat as **soft** telemetry."
    )
    return "\n".join(lines_out)


def _reject_section(trig: dict[str, dict[str, Any]]) -> str:
    lines_out: list[str] = []
    for name, st in trig.items():
        fp = st["false_positive_rate_guardrail_current_final"]
        prec = st["approx_precision_gold_absent_given_fired"]
        if fp > 0.35:
            lines_out.append(
                f"- **`{name}`:** guardrail FP **{fp:.2f}** — reject as a standalone hard trigger."
            )
        elif prec == 0.0 and st["fired_total_across_buckets"] > 0:
            lines_out.append(
                f"- **`{name}`:** precision-like **{prec:.2f}** when conditioned on fired — not gold-absent-targeted here."
            )
    if not lines_out:
        return (
            "No hard rejection beyond slice review; still avoid **`low_cov_and_missing_operation_cue`** as "
            "discovery-targeted when precision-like is **0**."
        )
    return "\n".join(lines_out)


if __name__ == "__main__":
    main()
