#!/usr/bin/env python3
"""Offline replay: structural commitment v1 vs Track B (no API; gold only for scoring)."""

from __future__ import annotations

import argparse
import csv
import json
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from experiments.output_layer_repair import (  # noqa: E402
    decide_structural_commitment_v1,
    decide_track_b_overlay_commitment_gate,
)
from scripts.replay_track_b_commitment_gate import (  # noqa: E402
    BUNDLE,
    PAL_METHOD,
    counterfactual_matches_gold,
    gold_norm,
    load_casebook_cohorts,
    load_pal_rows_by_case,
    signals_from_pal_all_results,
    signals_from_replay_table_row,
)

DEFAULT_BUNDLE = REPO_ROOT / BUNDLE
DEFAULT_DIAGNOSIS = (
    REPO_ROOT
    / "outputs/present_not_selected_commitment_diagnosis_20260508T004419Z"
    / "present_not_selected_commitment_cases.csv"
)
ANCHORS = {"openai_gsm8k_1087", "openai_gsm8k_1279", "openai_gsm8k_1290"}


def _load_diagnosis_case_ids(path: Path) -> list[str]:
    with path.open(encoding="utf-8") as f:
        return [r["case_id"] for r in csv.DictReader(f) if r.get("case_id")]


def _eval_pair(
    *,
    case_id: str,
    cohort: str,
    baseline_correct: bool | None,
    gold: str,
    counts: dict[str, Any],
    tiebreak_meta: dict[str, Any],
    pal_flat: dict[str, Any],
    overlay: dict[str, Any],
    dr_raw: str,
    meta_missing: bool,
    mechanism: str = "",
) -> dict[str, Any]:
    tb_dec = decide_track_b_overlay_commitment_gate(
        combined_group_counts_base=dict(counts),
        tiebreak_meta=dict(tiebreak_meta),
        pal_execution_flat=dict(pal_flat),
        overlay_tiebreak_summary=dict(overlay) if overlay else None,
    )
    st_dec = decide_structural_commitment_v1(
        combined_group_counts_base=dict(counts),
        tiebreak_meta=dict(tiebreak_meta),
        pal_execution_flat=dict(pal_flat),
        overlay_tiebreak_summary=dict(overlay) if overlay else None,
        direct_reserve_answer_raw=dr_raw or None,
    )
    tb_over = bool(tb_dec.get("should_override"))
    st_over = bool(st_dec.get("should_override"))
    tb_cf = counterfactual_matches_gold(tb_dec, gold)
    st_cf = counterfactual_matches_gold(st_dec, gold)
    tb_fix = tb_cf is True
    st_fix = st_cf is True
    layer = str(st_dec.get("commitment_policy_layer") or "")

    row: dict[str, Any] = {
        "case_id": case_id,
        "cohort": cohort,
        "primary_commitment_mechanism": mechanism,
        "gold_normalized": gold_norm(gold),
        "baseline_correct": "" if baseline_correct is None else int(baseline_correct),
        "metadata_missing": int(meta_missing),
        "track_b_should_override": int(tb_over),
        "structural_should_override": int(st_over),
        "track_b_gate_reason": tb_dec.get("reason"),
        "structural_gate_reason": st_dec.get("reason"),
        "commitment_policy_layer": layer,
        "track_b_counterfactual_matches_gold": "" if tb_cf is None else int(tb_cf),
        "structural_counterfactual_matches_gold": "" if st_cf is None else int(st_cf),
        "fixed_by_existing_track_b": int(tb_fix),
        "fixed_by_structural_commit_v1": int(st_fix),
        "additional_fixes_over_track_b": int(st_fix and not tb_fix),
    }

    reason_s = str(st_dec.get("reason") or "")
    if meta_missing or not gold:
        row["outcome_tag_structural"] = "unknown_no_replay_data"
    elif baseline_correct is False:
        if st_over and st_fix:
            if tb_fix:
                row["outcome_tag_structural"] = "fixed_by_structural_same_as_track_b"
            elif layer == "track_b":
                row["outcome_tag_structural"] = "fixed_by_structural_track_b_layer"
            else:
                row["outcome_tag_structural"] = "fixed_by_structural_commit_v1"
        elif st_over and st_cf is False:
            row["outcome_tag_structural"] = "worsened_or_neutral_structural_override"
        elif not st_over:
            if reason_s.startswith("abstain"):
                row["outcome_tag_structural"] = "abstained"
            else:
                row["outcome_tag_structural"] = "unchanged_still_wrong"
        else:
            row["outcome_tag_structural"] = "unknown_target_outcome"
    elif baseline_correct is True:
        if st_over and st_cf is False:
            row["outcome_tag_structural"] = "correct_to_wrong_regression"
        elif st_over:
            row["outcome_tag_structural"] = "override_keeps_correct"
        else:
            row["outcome_tag_structural"] = "unchanged_still_correct"
    else:
        row["outcome_tag_structural"] = "unknown_baseline"

    return row


def run_replay(
    *,
    bundle_dir: Path,
    diagnosis_csv: Path,
) -> dict[str, Any]:
    replay_csv = bundle_dir / "present_not_selected_replay_table.csv"
    casebook = bundle_dir / "all_casebook.csv"
    all_results = bundle_dir / "all_results.jsonl"

    diag_mechanism: dict[str, str] = {}
    if diagnosis_csv.is_file():
        with diagnosis_csv.open(encoding="utf-8") as f:
            for r in csv.DictReader(f):
                cid = r.get("case_id") or ""
                if cid:
                    diag_mechanism[cid] = r.get("primary_commitment_mechanism") or ""

    target_rows: dict[str, dict[str, str]] = {}
    with replay_csv.open(encoding="utf-8") as f:
        for row in csv.DictReader(f):
            target_rows[row["case_id"]] = row

    case_ids = _load_diagnosis_case_ids(diagnosis_csv) if diagnosis_csv.is_file() else sorted(target_rows.keys())

    both_ids, pal_only_ids = load_casebook_cohorts(casebook)
    pal_by_case = load_pal_rows_by_case(all_results)

    target_out: list[dict[str, Any]] = []
    for cid in case_ids:
        row = target_rows.get(cid)
        if not row:
            target_out.append(
                {
                    "case_id": cid,
                    "cohort": "target_pns_diagnosis",
                    "primary_commitment_mechanism": diag_mechanism.get(cid, ""),
                    "gold_normalized": "",
                    "baseline_correct": "0",
                    "metadata_missing": 1,
                    "track_b_should_override": "",
                    "structural_should_override": "",
                    "track_b_gate_reason": "missing_replay_row",
                    "structural_gate_reason": "",
                    "commitment_policy_layer": "",
                    "track_b_counterfactual_matches_gold": "",
                    "structural_counterfactual_matches_gold": "",
                    "fixed_by_existing_track_b": 0,
                    "fixed_by_structural_commit_v1": 0,
                    "additional_fixes_over_track_b": 0,
                    "outcome_tag_structural": "unknown_no_replay_data",
                }
            )
            continue
        gold = str(row.get("gold_normalized") or row.get("gold_answer_raw") or "")
        counts, tm, pf, ov, miss = signals_from_replay_table_row(row)
        dr = str(row.get("direct_reserve_answer") or "").strip()
        target_out.append(
            _eval_pair(
                case_id=cid,
                cohort="target_pns_diagnosis",
                baseline_correct=False,
                gold=gold,
                counts=counts,
                tiebreak_meta=tm,
                pal_flat=pf,
                overlay=ov,
                dr_raw=dr,
                meta_missing=miss,
                mechanism=str(row.get("primary_commitment_mechanism") or diag_mechanism.get(cid, "")),
            )
        )

    guard_out: list[dict[str, Any]] = []
    for cid in sorted(both_ids | pal_only_ids):
        obj = pal_by_case.get(cid)
        cohort = "guardrail_both_correct" if cid in both_ids else "guardrail_pal_only_correct"
        mechanism = ""
        if obj is None:
            guard_out.append(
                {
                    "case_id": cid,
                    "cohort": cohort,
                    "primary_commitment_mechanism": mechanism,
                    "gold_normalized": "",
                    "baseline_correct": "",
                    "metadata_missing": 1,
                    "track_b_should_override": "",
                    "structural_should_override": "",
                    "track_b_gate_reason": "missing_pal_row_in_all_results",
                    "structural_gate_reason": "",
                    "commitment_policy_layer": "",
                    "track_b_counterfactual_matches_gold": "",
                    "structural_counterfactual_matches_gold": "",
                    "fixed_by_existing_track_b": 0,
                    "fixed_by_structural_commit_v1": 0,
                    "additional_fixes_over_track_b": 0,
                    "outcome_tag_structural": "missing_row",
                }
            )
            continue
        gold = str(obj.get("normalized_gold_answer") or obj.get("gold_answer") or "")
        baseline_ok = bool(int(obj.get("exact_match") or 0) == 1)

        counts, tm, pf, ov, miss = signals_from_pal_all_results(obj)
        guard_out.append(
            _eval_pair(
                case_id=cid,
                cohort=cohort,
                baseline_correct=baseline_ok,
                gold=gold,
                counts=counts,
                tiebreak_meta=tm,
                pal_flat=pf,
                overlay=ov,
                dr_raw="",
                meta_missing=miss,
                mechanism="",
            )
        )

    def summarize_targets(rows: list[dict[str, Any]]) -> dict[str, Any]:
        rr = [x for x in rows if x.get("cohort") == "target_pns_diagnosis"]
        return {
            "rows": len(rr),
            "unknown_no_replay_data": sum(1 for x in rr if x.get("outcome_tag_structural") == "unknown_no_replay_data"),
            "fixed_by_structural_commit_v1": sum(1 for x in rr if int(x.get("fixed_by_structural_commit_v1") or 0) == 1),
            "fixed_by_existing_track_b": sum(1 for x in rr if int(x.get("fixed_by_existing_track_b") or 0) == 1),
            "additional_fixes_over_track_b": sum(
                1 for x in rr if int(x.get("additional_fixes_over_track_b") or 0) == 1
            ),
            "unchanged_still_wrong": sum(1 for x in rr if x.get("outcome_tag_structural") == "unchanged_still_wrong"),
            "abstained": sum(1 for x in rr if x.get("outcome_tag_structural") == "abstained"),
        }

    def summarize_guard(rows: list[dict[str, Any]]) -> dict[str, Any]:
        return {
            "rows": len(rows),
            "metadata_missing_rows": sum(1 for x in rows if int(x.get("metadata_missing") or 0) == 1),
            "correct_to_wrong_regressions": sum(
                1 for x in rows if x.get("outcome_tag_structural") == "correct_to_wrong_regression"
            ),
        }

    anchor_rows = [x for x in target_out + guard_out if x.get("case_id") in ANCHORS]
    seen: set[str] = set()
    anchor_summary: dict[str, Any] = {}
    for r in anchor_rows:
        cid = str(r.get("case_id") or "")
        if not cid or cid in seen:
            continue
        seen.add(cid)
        anchor_summary[cid] = {
            "cohort": r.get("cohort"),
            "structural_should_override": r.get("structural_should_override"),
            "track_b_should_override": r.get("track_b_should_override"),
            "commitment_policy_layer": r.get("commitment_policy_layer"),
            "matches_track_b_override": int(r.get("structural_should_override") or 0)
            == int(r.get("track_b_should_override") or 0),
        }

    fixes_by_mech = Counter()
    for x in target_out:
        if int(x.get("additional_fixes_over_track_b") or 0) == 1:
            fixes_by_mech[x.get("primary_commitment_mechanism") or "unknown"] += 1

    summary = {
        "bundle": str(bundle_dir),
        "diagnosis_csv": str(diagnosis_csv),
        "gate_functions": ["decide_track_b_overlay_commitment_gate", "decide_structural_commitment_v1"],
        "pal_method": PAL_METHOD,
        "targets": summarize_targets(target_out),
        "guardrails_all": summarize_guard(guard_out),
        "anchor_subset_openai_gsm8k": sorted(ANCHORS),
        "anchors_track_b_subset": anchor_summary,
        "fixes_by_mechanism_additional_over_track_b": dict(fixes_by_mech),
        "notes": {
            "guardrail_cohort": "183 both-correct + 5 pal-only rows on band 1072-1318 when present in all_results.jsonl",
            "guardrail_subset_note": "Full 188 ids from casebook; rows depend on PAL-method match in all_results.jsonl (see metadata_missing_rows).",
        },
    }
    return {"summary": summary, "rows": target_out + guard_out}


def write_out(out_dir: Path, data: dict[str, Any]) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "structural_commit_v1_replay_summary.json").write_text(
        json.dumps(data["summary"], indent=2), encoding="utf-8"
    )
    fieldnames = list(data["rows"][0].keys()) if data["rows"] else []
    with (out_dir / "structural_commit_v1_replay_cases.csv").open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        w.writeheader()
        for row in data["rows"]:
            w.writerow(row)

    s = data["summary"]
    md = "\n".join(
        [
            "# Structural commitment v1 — offline replay",
            "",
            f"Output: `{out_dir}`",
            "",
            "## Targets (PNS diagnosis case IDs)",
            f"```json\n{json.dumps(s['targets'], indent=2)}\n```",
            "",
            "## Guardrails",
            f"```json\n{json.dumps(s['guardrails_all'], indent=2)}\n```",
            "",
            "## Additional fixes by mechanism (structural only, not Track B)",
            f"```json\n{json.dumps(s['fixes_by_mechanism_additional_over_track_b'], indent=2)}\n```",
            "",
            "Gold used for scoring only. Gate logic is gold-free.",
        ]
    )
    (out_dir / "structural_commit_v1_report.md").write_text(md, encoding="utf-8")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--bundle-dir", type=Path, default=DEFAULT_BUNDLE)
    ap.add_argument("--diagnosis-csv", type=Path, default=DEFAULT_DIAGNOSIS)
    ap.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help="Default: outputs/structural_commit_v1_replay_UTCtimestamp",
    )
    args = ap.parse_args()
    out_dir = args.output_dir
    if out_dir is None:
        ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        out_dir = REPO_ROOT / "outputs" / f"structural_commit_v1_replay_{ts}"
    data = run_replay(bundle_dir=args.bundle_dir.resolve(), diagnosis_csv=args.diagnosis_csv.resolve())
    write_out(out_dir.resolve(), data)
    print(f"Wrote {out_dir.resolve()}")


if __name__ == "__main__":
    main()
