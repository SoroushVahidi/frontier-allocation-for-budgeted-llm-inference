from __future__ import annotations

import ast
import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

from experiments.target_staged_pal_pilot_dry_run import run_dry_run
from experiments.target_staged_pal_prompt import VARIANT_C

REPO_ROOT = Path(__file__).resolve().parents[1]
MANIFEST = REPO_ROOT / "manifests" / "target_staged_pal_retry_primary_11_20260507.json"
DRY_RUN_SOURCE = REPO_ROOT / "experiments" / "target_staged_pal_pilot_dry_run.py"


def _forbidden_top_level_import_roots(src: str) -> list[str]:
    tree = ast.parse(src)
    bad: list[str] = []
    forbidden = (
        "cohere",
        "openai",
        "anthropic",
        "requests",
        "httpx",
        "urllib3",
        "aiohttp",
        "boto3",
        "google",
    )
    for node in tree.body:
        if isinstance(node, ast.Import):
            for alias in node.names:
                base = (alias.name or "").split(".")[0]
                if base in forbidden:
                    bad.append(alias.name or base)
        elif isinstance(node, ast.ImportFrom):
            base = (node.module or "").split(".")[0]
            if base in forbidden:
                bad.append(node.module or "")
    return bad


def test_dry_run_source_imports_no_external_api_packages() -> None:
    src = DRY_RUN_SOURCE.read_text(encoding="utf-8")
    assert _forbidden_top_level_import_roots(src) == []


def test_dry_run_succeeds_with_real_manifest(tmp_path: Path) -> None:
    out = tmp_path / "dry"
    summary = run_dry_run(manifest_path=MANIFEST, out_dir=out)
    assert summary["prompts_materialized"] == 11
    assert summary["api_execution_enabled"] is False
    assert summary["hard_logical_call_cap"] == 120
    assert summary["soft_logical_call_cap"] == 80
    assert summary["no_external_api_called"] is True

    lines = (out / "materialized_prompts.jsonl").read_text(encoding="utf-8").splitlines()
    assert len(lines) == 11

    disk_summary = json.loads((out / "dry_run_summary.json").read_text(encoding="utf-8"))
    assert disk_summary["api_execution_enabled"] is False
    assert disk_summary["hard_logical_call_cap"] == 120

    prev = (out / "prompt_preview.md").read_text(encoding="utf-8")
    assert "Prompt 1" in prev or "## Prompt 1" in prev


def test_dry_run_rejects_oracle_case(tmp_path: Path) -> None:
    m = json.loads(MANIFEST.read_text(encoding="utf-8"))
    cases = list(m["cases"])
    row = dict(cases[0])
    row["template_variant"] = VARIANT_C
    cases[0] = row
    m["cases"] = cases
    bad_path = tmp_path / "bad.json"
    bad_path.write_text(json.dumps(m), encoding="utf-8")
    with pytest.raises(ValueError, match="non-deployable"):
        run_dry_run(manifest_path=bad_path, out_dir=tmp_path / "o")


def test_dry_run_cli_module_invocation(tmp_path: Path) -> None:
    out = tmp_path / "cli_out"
    cmd = [
        sys.executable,
        "-m",
        "experiments.target_staged_pal_pilot_dry_run",
        "--manifest",
        str(MANIFEST),
        "--out",
        str(out),
    ]
    env = {**os.environ, "PYTHONPATH": str(REPO_ROOT)}
    r = subprocess.run(cmd, cwd=REPO_ROOT, env=env, capture_output=True, text=True)
    assert r.returncode == 0, r.stderr + r.stdout
    assert (out / "dry_run_summary.json").is_file()
    assert len((out / "materialized_prompts.jsonl").read_text().splitlines()) == 11
