from __future__ import annotations

import csv
from pathlib import Path

import pytest

from experiments.target_staged_pal_prompt import VARIANT_A, VARIANT_B, VARIANT_C, materialize_user_prompt
from experiments.target_staged_pal_pilot_manifest import (
    EXPECTED_PRIMARY_CASE_IDS,
    PRIMARY_PILOT_MANIFEST_PATH,
    assert_oracle_variant_rejected_for_pilot,
    load_primary_pilot_manifest,
    validate_deployable_pilot_manifest,
)

REPO_ROOT = Path(__file__).resolve().parents[1]
SCHEMA_MINING_CSV = (
    REPO_ROOT
    / "outputs/gold_absent_external_success_schema_mining_20260507"
    / "schema_mining_cases.csv"
)


def _mining_rows_by_id() -> dict[str, dict[str, str]]:
    out: dict[str, dict[str, str]] = {}
    with SCHEMA_MINING_CSV.open(encoding="utf-8", newline="") as f:
        for row in csv.DictReader(f):
            if row.get("selection_tier") == "primary_external_correct":
                out[row["case_id"]] = row
    return out


def test_manifest_file_exists() -> None:
    assert PRIMARY_PILOT_MANIFEST_PATH.is_file()


def test_validate_primary_manifest_passes() -> None:
    m = load_primary_pilot_manifest()
    validate_deployable_pilot_manifest(m)


def test_exactly_eleven_primary_ids_no_duplicates() -> None:
    m = load_primary_pilot_manifest()
    ids = [str(c["source_case_id"]) for c in m["cases"]]
    assert len(ids) == 11
    assert len(set(ids)) == 11
    assert set(ids) == set(EXPECTED_PRIMARY_CASE_IDS)


def test_all_template_variants_deployable() -> None:
    m = load_primary_pilot_manifest()
    for c in m["cases"]:
        assert c["template_variant"] in (VARIANT_A, VARIANT_B)


def test_oracle_variant_rejected_by_guard() -> None:
    with pytest.raises(ValueError, match="cannot be used"):
        assert_oracle_variant_rejected_for_pilot(VARIANT_C)


def test_validate_rejects_manifest_with_oracle_case() -> None:
    m = load_primary_pilot_manifest()
    bad = dict(m)
    bad_cases = list(m["cases"])
    bad_row = dict(bad_cases[0])
    bad_row["template_variant"] = VARIANT_C
    bad_cases[0] = bad_row
    bad["cases"] = bad_cases
    with pytest.raises(ValueError, match="non-deployable"):
        validate_deployable_pilot_manifest(bad)


def test_api_disabled_and_hard_cap_120() -> None:
    m = load_primary_pilot_manifest()
    assert m.get("api_execution_enabled") is False
    assert m.get("hard_logical_call_cap") == 120
    assert m.get("default_template_variant") == VARIANT_B
    assert m.get("soft_logical_call_cap") == 80
    assert m.get("per_case_budget") == 6


def test_metadata_not_in_materialized_prompts() -> None:
    m = load_primary_pilot_manifest()
    mining = _mining_rows_by_id()
    for c in m["cases"]:
        cid = c["source_case_id"]
        row = mining[cid]
        question = str(row["problem_text"] or "").strip()
        tv = str(c["template_variant"])
        prompt = materialize_user_prompt(tv, question=question)
        assert cid not in prompt
        assert str(c["required_schemas"]) not in prompt
        assert str(c["pal_failure_modes"]) not in prompt
        assert "required_schemas" not in prompt
        assert "pal_failure_modes" not in prompt
        assert "source_case_id" not in prompt
