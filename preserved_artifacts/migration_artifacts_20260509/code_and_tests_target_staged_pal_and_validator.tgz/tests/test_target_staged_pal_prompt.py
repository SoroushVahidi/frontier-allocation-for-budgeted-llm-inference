from __future__ import annotations

from pathlib import Path

import pytest

from experiments.pal_executor import execute_pal_code
from experiments.target_staged_pal_prompt import (
    DEPLOYABLE_VARIANTS,
    NON_DEPLOYABLE_VARIANTS,
    VARIANT_A,
    VARIANT_B,
    VARIANT_C,
    all_sections_present,
    assert_deployable_pilot_variant,
    extract_python_for_pal_executor,
    is_deployable_variant,
    materialize_user_prompt,
    parse_staged_model_output,
    prompt_includes_required_sections_instruction,
    resolve_pilot_manifest_template,
    variant_b_leakage_violations,
    load_user_template,
)

FIXTURES = Path(__file__).resolve().parent / "fixtures" / "target_staged_pal"


def _question_1099() -> str:
    return (FIXTURES / "openai_gsm8k_1099_question.txt").read_text(encoding="utf-8").strip()


def test_templates_exist_for_all_variants() -> None:
    for v in (VARIANT_A, VARIANT_B, VARIANT_C):
        assert load_user_template(v)


def test_variant_c_non_deployable() -> None:
    assert VARIANT_C in NON_DEPLOYABLE_VARIANTS
    assert VARIANT_C not in DEPLOYABLE_VARIANTS
    assert is_deployable_variant(VARIANT_A) is True
    assert is_deployable_variant(VARIANT_B) is True
    assert is_deployable_variant(VARIANT_C) is False


def test_assert_deployable_rejects_oracle_variant() -> None:
    with pytest.raises(ValueError, match="non-deployable"):
        assert_deployable_pilot_variant(VARIANT_C)


def test_manifest_resolution_rejects_variant_c() -> None:
    with pytest.raises(ValueError):
        resolve_pilot_manifest_template({"template_variant": VARIANT_C})


def test_manifest_resolution_accepts_variant_a() -> None:
    assert resolve_pilot_manifest_template({"template_variant": VARIANT_A}) == VARIANT_A


def test_deployable_templates_single_question_placeholder() -> None:
    for v in DEPLOYABLE_VARIANTS:
        raw = load_user_template(v)
        assert raw.count("{question}") == 1
        assert "{oracle_hint}" not in raw


def test_materialized_a_and_b_include_all_six_section_headers() -> None:
    q = _question_1099()
    pa = materialize_user_prompt(VARIANT_A, question=q)
    pb = materialize_user_prompt(VARIANT_B, question=q)
    assert prompt_includes_required_sections_instruction(pa)
    assert prompt_includes_required_sections_instruction(pb)
    assert q in pa and q in pb


def test_materialized_b_has_no_leakage_tokens() -> None:
    q = _question_1099()
    prompt_b = materialize_user_prompt(VARIANT_B, question=q)
    assert variant_b_leakage_violations(prompt_b) == []


def test_materialized_a_b_are_question_plus_instructions_only() -> None:
    """Prompt is static template with exactly one substituted GSM8K question."""
    q = _question_1099()
    for v in DEPLOYABLE_VARIANTS:
        template = load_user_template(v)
        expected = template.replace("{question}", q)
        assert materialize_user_prompt(v, question=q) == expected


def test_sample_fixture_output_parses_and_executes_in_sandbox() -> None:
    raw = (FIXTURES / "sample_model_output_1099.txt").read_text(encoding="utf-8")
    parsed = parse_staged_model_output(raw)
    assert all_sections_present(parsed)
    code = extract_python_for_pal_executor(parsed["python"])
    result = execute_pal_code(code)
    assert result.pal_parse_ok is True
    assert result.pal_safety_ok is True
    assert result.pal_exec_ok is True
    assert result.pal_answer_normalized == "2450"


def test_parse_staged_model_output_requires_all_markers() -> None:
    parsed = parse_staged_model_output("TARGET:\nx\nUNITS:\ny\n")
    assert parsed["target"] == "x"
    assert parsed["units"] == "y"
    assert parsed["python"] == ""
