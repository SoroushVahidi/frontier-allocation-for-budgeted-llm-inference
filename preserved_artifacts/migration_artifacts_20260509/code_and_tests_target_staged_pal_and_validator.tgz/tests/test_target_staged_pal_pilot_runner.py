from __future__ import annotations

import ast
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

import pytest

from experiments.target_staged_pal_pilot_manifest import (
    PRIMARY_PILOT_MANIFEST_PATH,
    validate_pilot_manifest_structure,
)
from experiments.target_staged_pal_prompt import VARIANT_C
from experiments.target_staged_pal_pilot_runner import (
    REPO_ROOT,
    run_target_staged_pal_pilot,
)

RUNNER_SOURCE = REPO_ROOT / "experiments" / "target_staged_pal_pilot_runner.py"
SAMPLE_OUT = Path(__file__).resolve().parent / "fixtures" / "target_staged_pal" / "sample_model_output_1099.txt"


def _forbidden_top_level_import_roots(src: str) -> list[str]:
    tree = ast.parse(src)
    bad: list[str] = []
    forbidden = (
        "cohere",
        "openai",
        "anthropic",
        "requests",
        "httpx",
        "aiohttp",
    )
    for node in tree.body:
        if isinstance(node, ast.Import):
            for alias in node.names:
                base = (alias.name or "").split(".")[0]
                if base in forbidden:
                    bad.append(alias.name or base)
        elif isinstance(node, ast.ImportFrom):
            base = (node.module or "").split(".")[0]
            if base in forbidden:
                bad.append(node.module or "")
    return bad


def test_runner_module_has_no_top_level_cohere_import() -> None:
    src = RUNNER_SOURCE.read_text(encoding="utf-8")
    assert _forbidden_top_level_import_roots(src) == []


def test_importing_runner_does_not_load_cohere_subprocess() -> None:
    code = (
        "import sys\n"
        "sys.modules.pop('cohere', None)\n"
        "import experiments.target_staged_pal_pilot_runner\n"
        "assert 'cohere' not in sys.modules\n"
    )
    subprocess.check_call(
        [sys.executable, "-c", code],
        cwd=REPO_ROOT,
        env={**os.environ, "PYTHONPATH": str(REPO_ROOT)},
    )


def test_unarmed_run_returns_without_api(tmp_path: Path) -> None:
    s = run_target_staged_pal_pilot(
        manifest_path=PRIMARY_PILOT_MANIFEST_PATH,
        out_dir=tmp_path / "out",
        execute_api=False,
    )
    assert s.get("status") == "not_armed"
    assert not list((tmp_path / "out").glob("*"))


def test_armed_requires_manifest_api_true(tmp_path: Path) -> None:
    with pytest.raises(ValueError, match="api_execution_enabled"):
        run_target_staged_pal_pilot(
            manifest_path=PRIMARY_PILOT_MANIFEST_PATH,
            out_dir=tmp_path / "out",
            execute_api=True,
            model_fn=lambda **_: (SAMPLE_OUT.read_text(encoding="utf-8"), 1),
        )


def _manifest_with_api(*, api: bool, per_case_budget: int = 6) -> dict[str, Any]:
    m = json.loads(PRIMARY_PILOT_MANIFEST_PATH.read_text(encoding="utf-8"))
    m = json.loads(json.dumps(m))
    m["api_execution_enabled"] = api
    m["per_case_budget"] = per_case_budget
    planned = per_case_budget * len(m["cases"])
    if planned > int(m["hard_logical_call_cap"]):
        pass
    return m


def test_planned_logical_exceeds_hard_cap_raises(tmp_path: Path) -> None:
    m = _manifest_with_api(api=True, per_case_budget=12)
    path = tmp_path / "m.json"
    path.write_text(json.dumps(m), encoding="utf-8")
    with pytest.raises(ValueError, match="exceeds"):
        run_target_staged_pal_pilot(
            manifest_path=path,
            out_dir=tmp_path / "o",
            execute_api=True,
            model_fn=lambda **_: ("", 1),
        )


def test_oracle_template_rejected(tmp_path: Path) -> None:
    m = _manifest_with_api(api=True)
    cases = list(m["cases"])
    row = dict(cases[0])
    row["template_variant"] = VARIANT_C
    cases[0] = row
    m["cases"] = cases
    path = tmp_path / "m.json"
    path.write_text(json.dumps(m), encoding="utf-8")
    with pytest.raises(ValueError, match="non-deployable"):
        validate_pilot_manifest_structure(m)


@pytest.fixture
def armed_manifest_path(tmp_path: Path) -> Path:
    m = _manifest_with_api(api=True, per_case_budget=6)
    p = tmp_path / "armed.json"
    p.write_text(json.dumps(m), encoding="utf-8")
    return p


def test_fake_model_writes_case_results(armed_manifest_path: Path, tmp_path: Path) -> None:
    sample = SAMPLE_OUT.read_text(encoding="utf-8")

    def _fake(**_: Any) -> tuple[str, int]:
        return sample, 1

    out = tmp_path / "pilot_out"
    s = run_target_staged_pal_pilot(
        manifest_path=armed_manifest_path,
        out_dir=out,
        execute_api=True,
        model_fn=_fake,
    )
    assert s["status"] == "completed"
    lines = (out / "case_results.jsonl").read_text(encoding="utf-8").splitlines()
    assert len(lines) == 11
    assert (out / "run_summary.json").is_file()
    assert (out / "config_snapshot.json").is_file()
    assert (out / "prompts_snapshot.jsonl").is_file()
    assert (out / "failures.jsonl").is_file()


def test_total_logical_calls_stays_within_hard_cap(tmp_path: Path) -> None:
    """With valid per_case_budget, single-call-per-case cannot exceed planned ceiling (<= hard cap)."""
    sample = SAMPLE_OUT.read_text(encoding="utf-8")

    def _fn(**_: Any) -> tuple[str, int]:
        return sample, 6

    armed = tmp_path / "armed.json"
    armed.write_text(json.dumps(_manifest_with_api(api=True, per_case_budget=6)), encoding="utf-8")

    out = tmp_path / "o"
    s = run_target_staged_pal_pilot(
        manifest_path=armed,
        out_dir=out,
        execute_api=True,
        model_fn=_fn,
    )
    assert s["total_logical_calls_used"] == 66
    assert s["hard_logical_call_cap"] == 120
    assert s["total_logical_calls_used"] <= int(s["hard_logical_call_cap"])


def test_cli_without_execute_api_exits_zero(tmp_path: Path) -> None:
    r = subprocess.run(
        [
            sys.executable,
            "-m",
            "experiments.target_staged_pal_pilot_runner",
            "--manifest",
            str(PRIMARY_PILOT_MANIFEST_PATH),
            "--out",
            str(tmp_path / "cliout"),
        ],
        cwd=REPO_ROOT,
        env={**os.environ, "PYTHONPATH": str(REPO_ROOT)},
        capture_output=True,
        text=True,
    )
    assert r.returncode == 0, r.stderr


def test_cli_execute_api_with_manifest_api_false_exits_two(tmp_path: Path) -> None:
    r = subprocess.run(
        [
            sys.executable,
            "-m",
            "experiments.target_staged_pal_pilot_runner",
            "--manifest",
            str(PRIMARY_PILOT_MANIFEST_PATH),
            "--out",
            str(tmp_path / "cliout"),
            "--execute-api",
        ],
        cwd=REPO_ROOT,
        env={**os.environ, "PYTHONPATH": str(REPO_ROOT)},
        capture_output=True,
        text=True,
    )
    assert r.returncode == 2, r.stdout + r.stderr
