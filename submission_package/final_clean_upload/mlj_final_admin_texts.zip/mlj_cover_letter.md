# MLJ Cover Letter Draft

Dear Editor,

Please consider our manuscript, *Failure-Trace-Guided Answer Allocation for Budgeted LLM Reasoning*, for publication in *Machine Learning*.

The manuscript studies matched-budget answer selection for GSM8K under Cohere command-r-plus-08-2024. Its promoted policy, FIX-2+FIX-4, is a deterministic gold-free gate that uses runtime failure-trace metadata and external consensus signals.

On Final-300, FIX-2+FIX-4 achieves 260/300 = 86.67%. On the disjoint Aggregate-720 evaluation, it achieves 581/720 = 80.69%. Source-stratified bootstrap confidence intervals are positive versus L1, S1, TALE, and the source-local best external baseline.

The claims are scoped to the tested provider, benchmark, and budget-6 setting. We do not claim universal superiority.

Implementation and processed evaluation artifacts will be made publicly available upon acceptance in a versioned repository, preferably with a persistent identifier such as a Zenodo DOI. A supplementary reproducibility package is included with this submission, and additional processed artifacts can be provided to reviewers upon request.

I will disclose the related conference manuscript under review for transparency. That manuscript focuses on a broader frontier-allocation formulation with matched action-budget analysis and internal frontier controls. The present MLJ submission focuses on FIX-2+FIX-4, GSM8K Final-300 and Aggregate-720, L1 / S1 / TALE comparisons, source-stratified bootstrap confidence intervals, and runtime-legal no-gold triggers.

If helpful for editorial review, I can provide the related manuscript to the editor upon request.

Sincerely,
Soroush Vahidi
