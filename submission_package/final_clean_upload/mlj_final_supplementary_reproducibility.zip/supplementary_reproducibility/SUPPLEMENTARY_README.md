# Supplementary Reproducibility Bundle (Reviewer-Facing)

This archive intentionally includes only concise, reviewer-relevant reproducibility material.

Included:
- Canonical safe-claims/results summary (`LATEST_RESULTS_AND_CLAIMS.md`)
- Reproducibility and sensitivity tables referenced by the manuscript appendix
- Artifact release plan note

Not included:
- Full `outputs/` tree
- API keys, credentials, `.env` files, private tokens, or secrets
- Raw restricted provider payloads
- Private development notes unrelated to review
- Unrelated large artifacts
