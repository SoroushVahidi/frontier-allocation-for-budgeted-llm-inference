# Supplementary Reproducibility Bundle (Clean)

This bundle is intentionally lightweight and reviewer-facing.
It contains reproducibility-oriented metadata and manuscript-linked evidence summaries,
without private repository contents, credentials, or large/raw provider outputs.

Included:
- Canonical current claims snapshot (`LATEST_RESULTS_AND_CLAIMS.md`)
- Manuscript reproducibility checklist table source (`tableA1_reproducibility.tex`)
- Parameter-grounding table source (`tableA4_parameter_sensitivity.tex`)
- Runtime feature-legality table source (`tableA5_feature_legality.tex`)
- Win/loss/tie decomposition table source (`tableA2_win_loss_tie.tex`)
- Artifact-release policy note (`artifact_release_plan.md`)

Not included:
- API keys, tokens, `.env`, secrets
- Private development notes beyond release policy
- Large/raw exploratory outputs under `outputs/`
- Restricted provider payload artifacts
