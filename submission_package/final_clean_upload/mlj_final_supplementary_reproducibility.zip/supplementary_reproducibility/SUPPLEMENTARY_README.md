# Supplementary Reproducibility Bundle

This supplementary bundle provides reviewer-facing reproducibility notes and selected appendix tables.
It intentionally excludes raw provider outputs, API keys, private notes, and the full `outputs/` tree.
