# Supplementary Reproducibility Bundle

This supplementary bundle provides reviewer-facing reproducibility notes, selected appendix tables, and reviewer-risk analysis summaries supporting the MLJ submission.
It intentionally excludes raw provider outputs, API keys, private notes, `.env` files, caches, and the full `outputs/` tree.
