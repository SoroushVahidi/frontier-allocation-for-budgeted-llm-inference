# Supplementary Reproducibility Materials

This package contains reviewer-facing reproducibility materials aligned with the manuscript:
- Appendix reproducibility/sensitivity/feature-legality tables
- Canonical final results-and-claims record
- Artifact release policy

Excluded by design:
- full `outputs/` trees
- API keys, secrets, `.env`, or private tokens
- private/internal notes
- raw restricted provider outputs
- caches and unrelated large local artifacts
