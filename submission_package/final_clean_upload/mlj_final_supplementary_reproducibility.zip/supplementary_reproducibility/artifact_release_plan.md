# Artifact Release Plan

## Release policy

- Upon acceptance, the implementation and processed evaluation artifacts will be published in a versioned repository, preferably with a persistent identifier such as a Zenodo DOI.
- The supplementary reproducibility package included with this submission contains the processed artifacts needed to inspect the reported results.
- Additional processed artifacts can be provided to reviewers upon request.

## Planned release contents

- evaluation scripts needed to reproduce reported tables and figures
- processed CSV artifacts used for final claims
- bootstrap CI summary outputs
- win/loss/tie summaries
- figure source CSVs and plotting scripts
- manuscript-facing table-generation scripts where applicable

## Notes

- Live reruns require provider API access to Cohere command-r-plus-08-2024.
- Raw provider outputs and temporary build artifacts are excluded from the release.
